<?php
//define("dbpass", "");
define("dbname", "Fiat888!");
define("delta",-3599);
?>